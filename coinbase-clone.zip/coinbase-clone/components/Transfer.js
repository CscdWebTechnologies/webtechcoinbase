import React from 'react'
import { View, Text } from 'react-native'

const Transfer = () => {
    return (
        <View>
            <Text>transfer</Text>
        </View>
    )
}

export default Transfer
